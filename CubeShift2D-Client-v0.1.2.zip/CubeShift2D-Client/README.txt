CubeShift2D Client v0.1.2
=========================

This is a Windows desktop Electron application project for CubeShift2D.
It opens https://cubeshift2d.web.app/ in its own desktop game window and
injects a locally patched copy of the JavaScript gameplay bundle.

Included controls
-----------------
- Noclip
- Fly
- Invincibility
- Multi-jump
- Freeze player
- View hitboxes (player, enemies, and solid collision geometry)
- Speed multiplier
- Jump multiplier
- Teleport to start
- Teleport to latest checkpoint
- Instant finish (teleport to goal)
- Respawn
- Heal
- Edit current health (0-9999)
- Collect all level coins
- Coordinate teleport
- Live position / health / coin / velocity state

Build the Windows app
---------------------
1. Install Node.js LTS if you do not already have it.
2. Double-click build-windows.bat.
3. When it finishes, the dist folder contains the portable .exe and installer.

For a quick development run, double-click run-dev.bat.

Notes
-----
- The game page still loads from the official cubeshift2d.web.app origin so
  Firebase sign-in and the website origin remain the same.
- The Electron app intercepts the game's compiled JavaScript bundle request
  and supplies the patched local bundle included with this project.
- If CubeShift2D is redeployed with major gameplay code changes, regenerate
  the patch from the new compiled bundle.
- This client intentionally does not bypass bans, Firebase/Firestore security,
  or staff permissions. Moderation should continue through the game's real
  authorized staff system.

Fix in v0.1.1
-------------
- Module switches are now clickable across the whole switch control.
- A failed module change rolls the switch back instead of showing a false enabled state.


Added in v0.1.2
---------------
- View hitboxes module: shows the player collider, enemy colliders, duel-player colliders,
  and the game's actual solid collision geometry (including partial blocks) in the viewport.
- Health editor: enter a value from 0 to 9999 and press Set health (or Enter).
