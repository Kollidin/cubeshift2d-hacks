@echo off
setlocal
cd /d "%~dp0"
echo.
echo  CubeShift2D Client - Windows Builder
echo  ====================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install the current Node.js LTS release, then run this file again.
  pause
  exit /b 1
)
echo Installing app dependencies...
call npm install
if errorlevel 1 goto :fail
echo.
echo Building Windows application...
call npm run dist
if errorlevel 1 goto :fail
echo.
echo Done. Open the "dist" folder for the portable EXE and installer.
start "" "%~dp0dist"
pause
exit /b 0
:fail
echo.
echo Build failed. Scroll up for the error.
pause
exit /b 1
