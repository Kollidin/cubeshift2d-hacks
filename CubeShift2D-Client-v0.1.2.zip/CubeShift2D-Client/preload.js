const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('cubeClient', {
  set: (key, value) => ipcRenderer.invoke('hack:set', { key, value }),
  command: (name, args = []) => ipcRenderer.invoke('hack:command', { name, args }),
  state: () => ipcRenderer.invoke('hack:state'),
  reload: () => ipcRenderer.invoke('game:reload'),
  focusGame: () => ipcRenderer.invoke('game:focus'),
  openDevTools: () => ipcRenderer.invoke('game:devtools')
});
