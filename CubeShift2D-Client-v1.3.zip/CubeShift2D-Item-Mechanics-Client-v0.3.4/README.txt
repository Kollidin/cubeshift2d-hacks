CubeShift2D Item Mechanics Client v0.3.4
========================================

JavaScript / Node.js / Electron only. No Python is required on your PC.

New in v0.3.4
-------------
- Custom Teleporter coordinates.
- X and Y are measured in level BLOCKS instead of raw canvas pixels.
- X = blocks from the left side of the level.
- Y = blocks from the top of the level.
- (0, 0) is the top-left grid cell.
- Decimal coordinates are allowed (for example X 5.5, Y 8.25).
- T repeats the last X/Y target entered in the control panel.
- Live position now displays block coordinates.
- View Hitboxes remains available with H.

Hotkeys
-------
F = Fly / Cloud Mode toggle
I = Invincibility-ish / +10 HP block
G = Teleport to Goal
V = Speed Switch
C = All Coins teleporter sweep
M = Mode Switch
T = Teleport to the last custom X/Y block coordinates
J = Jump Block
R = Respawn / Checkpoint
N = Normal Speed
H = View Hitboxes

The hotkeys are ignored while you are typing into an input, textarea, select, or
content-editable field.

Custom Teleporter
-----------------
Enter X and Y in the control panel and press Teleport.

Examples:
X 0, Y 0     = top-left grid cell
X 10, Y 4    = 10 blocks from the left, 4 blocks from the top
X 10.5, Y 4  = halfway between horizontal grid cells 10 and 11

Coordinates outside the level are clamped to the nearest valid edge.

Mechanic emulation
------------------
- Fly uses Cloud Mode behavior.
- +10 HP uses the normal health-block amount and normal maximum health.
- Speed Switch and Jump Block reuse the existing level mechanics.
- Custom teleport, goal teleport, and All Coins use teleporter-style player relocation.
- All Coins moves through remaining coin positions so normal collision collection
  handles the coins instead of directly changing the saved coin total.

This build does not add ban bypasses, App Check bypasses, Firestore-rule bypasses,
or authentication bypasses. It is for testing whether the official backend rejects
impossible gameplay produced by a modified client.

Run
---
1. Install Node.js LTS.
2. Extract this ZIP to a new folder.
3. Double-click run-dev.bat.
4. Wait for the game and controls windows.
5. Open a level.
6. Enter custom Teleporter coordinates if wanted.
7. Use the buttons or hotkeys.

Build an EXE
------------
Double-click build-windows.bat. The output appears in dist.
