@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 pause & exit /b 1
)
echo Building Windows app...
call npm run dist
if errorlevel 1 pause & exit /b 1
echo.
echo Done. Check the dist folder.
pause
