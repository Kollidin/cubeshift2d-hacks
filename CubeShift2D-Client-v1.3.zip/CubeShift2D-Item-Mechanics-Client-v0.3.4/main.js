const { app, BrowserWindow, ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');

const GAME_URL = 'https://cubeshift2d.web.app/';
const GAME_ORIGIN = 'https://cubeshift2d.web.app';
const SHELL = fs.readFileSync(path.join(__dirname, 'game', 'client-shell.html'));
const PATCHED_BUNDLE = fs.readFileSync(path.join(__dirname, 'game', 'patched-bundle.js'));
const GAME_CSS = fs.readFileSync(path.join(__dirname, 'game', 'client.css'));

let gameWindow = null;
let controlsWindow = null;

function responseHeaders(contentType) {
  return [
    { name: 'Content-Type', value: contentType },
    { name: 'Cache-Control', value: 'no-store, no-cache, must-revalidate' },
    { name: 'Pragma', value: 'no-cache' },
    { name: 'Access-Control-Allow-Origin', value: GAME_ORIGIN }
  ];
}

async function execInGame(source) {
  if (!gameWindow || gameWindow.isDestroyed()) return null;
  try {
    return await gameWindow.webContents.executeJavaScript(source, true);
  } catch (err) {
    console.error('Game execute error:', err?.message || err);
    return null;
  }
}

async function attachGameInterceptor(win) {
  const dbg = win.webContents.debugger;
  if (!dbg.isAttached()) dbg.attach('1.3');

  dbg.on('message', async (_event, method, params) => {
    if (method !== 'Fetch.requestPaused') return;

    const url = params.request?.url || '';
    const type = params.resourceType || '';

    try {
      // Serve the known CubeShift2D shell from the real cubeshift2d.web.app
      // origin. This avoids Subresource Integrity rejecting the patched bundle.
      if (type === 'Document' && (url === GAME_URL || url === GAME_ORIGIN || url.startsWith(`${GAME_ORIGIN}/?`))) {
        await dbg.sendCommand('Fetch.fulfillRequest', {
          requestId: params.requestId,
          responseCode: 200,
          responseHeaders: responseHeaders('text/html; charset=utf-8'),
          body: SHELL.toString('base64')
        });
        return;
      }

      if (type === 'Script' && url.startsWith(`${GAME_ORIGIN}/assets/cubeshift-item-client.js`)) {
        await dbg.sendCommand('Fetch.fulfillRequest', {
          requestId: params.requestId,
          responseCode: 200,
          responseHeaders: responseHeaders('text/javascript; charset=utf-8'),
          body: PATCHED_BUNDLE.toString('base64')
        });
        return;
      }

      if (type === 'Stylesheet' && url.startsWith(`${GAME_ORIGIN}/assets/cubeshift-item-client.css`)) {
        await dbg.sendCommand('Fetch.fulfillRequest', {
          requestId: params.requestId,
          responseCode: 200,
          responseHeaders: responseHeaders('text/css; charset=utf-8'),
          body: GAME_CSS.toString('base64')
        });
        return;
      }

      await dbg.sendCommand('Fetch.continueRequest', { requestId: params.requestId });
    } catch (err) {
      console.error('Interceptor error:', err?.message || err);
      try { await dbg.sendCommand('Fetch.continueRequest', { requestId: params.requestId }); } catch {}
    }
  });

  await dbg.sendCommand('Fetch.enable', {
    patterns: [
      { urlPattern: `${GAME_ORIGIN}/*`, requestStage: 'Request' }
    ]
  });
}

async function createGameWindow() {
  gameWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 650,
    title: 'CubeShift2D Item Mechanics Client',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#07101d',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      partition: 'persist:cubeshift2d-item-client-v034'
    }
  });

  gameWindow.webContents.on('did-fail-load', (_event, code, description, validatedURL, isMainFrame) => {
    if (isMainFrame) console.error(`Game failed to load: ${code} ${description} ${validatedURL}`);
  });
  gameWindow.webContents.on('render-process-gone', (_event, details) => {
    console.error('Game renderer stopped:', details.reason);
  });
  gameWindow.webContents.on('console-message', (_event, level, message, line, sourceId) => {
    if (level >= 2) console.log(`[Game console] ${message} (${sourceId}:${line})`);
  });

  gameWindow.webContents.on('before-input-event', (_event, input) => {
    if (input.type !== 'keyDown' || input.isAutoRepeat) return;
    if (input.control || input.alt || input.meta) return;
    handleItemHotkey(input.key);
  });

  await attachGameInterceptor(gameWindow);
  await gameWindow.loadURL(GAME_URL);

  gameWindow.on('closed', () => {
    gameWindow = null;
    if (controlsWindow && !controlsWindow.isDestroyed()) controlsWindow.close();
  });
}

function createControlsWindow() {
  controlsWindow = new BrowserWindow({
    width: 430,
    height: 760,
    minWidth: 380,
    minHeight: 620,
    title: 'CubeShift2D Item Mechanics',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#07101d',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  controlsWindow.loadFile(path.join(__dirname, 'controls.html'));
  controlsWindow.on('closed', () => { controlsWindow = null; });
}

const allowedCommands = new Set([
  'setCloud',
  'modeSwitch',
  'healthPlus10',
  'speedSwitch',
  'resetSpeed',
  'jumpBlock',
  'teleportNext',
  'setTeleportTarget',
  'teleportCoords',
  'teleportTarget',
  'teleportGoal',
  'collectAllCoins',
  'toggleHitboxes',
  'respawn'
]);

async function runItemCommand(name, args = []) {
  if (!allowedCommands.has(name)) return { ok: false, error: 'Unknown command' };
  const n = JSON.stringify(name);
  const a = JSON.stringify(Array.isArray(args) ? args : []);
  const result = await execInGame(`(() => {
    const active = document.activeElement;
    if (active && (active.matches?.('input, textarea, select') || active.isContentEditable)) {
      return { ok:false, error:'Typing in a field' };
    }
    const api = window.__CUBESHIFT_ITEM_API__;
    if (!api || typeof api[${n}] !== 'function') return { ok:false, error:'Open a level first' };
    try { return { ok:true, value:api[${n}](...${a}) }; }
    catch (e) { return { ok:false, error:String(e?.message || e) }; }
  })()`);
  return result || { ok: false, error: 'Game unavailable' };
}

function hotkeyMessage(key, name, result) {
  if (!controlsWindow || controlsWindow.isDestroyed()) return;
  controlsWindow.webContents.send('item:hotkey', {
    key: key.toUpperCase(),
    name,
    ok: !!result?.ok,
    value: result?.value,
    error: result?.error || ''
  });
}

async function handleItemHotkey(key) {
  const k = String(key || '').toLowerCase();
  const map = {
    f: ['modeSwitch', 'Fly / Cloud toggle'],
    i: ['healthPlus10', 'Invincibility-ish +10 HP'],
    g: ['teleportGoal', 'Teleport to goal'],
    v: ['speedSwitch', 'Speed switch'],
    c: ['collectAllCoins', 'All coins'],
    m: ['modeSwitch', 'Mode switch'],
    t: ['teleportTarget', 'Teleporter X/Y'],
    j: ['jumpBlock', 'Jump block'],
    r: ['respawn', 'Respawn / checkpoint'],
    n: ['resetSpeed', 'Normal speed'],
    h: ['toggleHitboxes', 'View hitboxes']
  };
  const entry = map[k];
  if (!entry) return;
  const [command, label] = entry;
  const result = await runItemCommand(command);
  hotkeyMessage(k, label, result);
}

ipcMain.handle('item:command', async (_event, { name, args }) => {
  return runItemCommand(name, args);
});

ipcMain.handle('item:state', async () => {
  return await execInGame(`(() => window.__CUBESHIFT_ITEM_API__?.getState?.() ?? null)()`);
});

ipcMain.handle('game:reload', async () => {
  if (!gameWindow || gameWindow.isDestroyed()) return false;
  await gameWindow.loadURL(GAME_URL);
  return true;
});

ipcMain.handle('game:focus', async () => {
  if (!gameWindow || gameWindow.isDestroyed()) return false;
  gameWindow.show();
  gameWindow.focus();
  return true;
});

ipcMain.handle('game:devtools', async () => {
  if (!gameWindow || gameWindow.isDestroyed()) return false;
  gameWindow.webContents.openDevTools({ mode: 'detach' });
  return true;
});

app.whenReady().then(async () => {
  await createGameWindow();
  createControlsWindow();
  app.on('activate', () => {
    if (!gameWindow) createGameWindow();
    if (!controlsWindow) createControlsWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
