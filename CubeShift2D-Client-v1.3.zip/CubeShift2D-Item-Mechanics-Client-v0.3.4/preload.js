const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('cubeItemClient', {
  command: (name, args = []) => ipcRenderer.invoke('item:command', { name, args }),
  state: () => ipcRenderer.invoke('item:state'),
  reload: () => ipcRenderer.invoke('game:reload'),
  focusGame: () => ipcRenderer.invoke('game:focus'),
  openDevTools: () => ipcRenderer.invoke('game:devtools'),
  onHotkey: (callback) => ipcRenderer.on('item:hotkey', (_event, data) => callback(data))
});
