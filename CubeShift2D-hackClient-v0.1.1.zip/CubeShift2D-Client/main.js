const { app, BrowserWindow, ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');

const GAME_URL = 'https://cubeshift2d.web.app/';
const PATCHED_BUNDLE = fs.readFileSync(path.join(__dirname, 'game', 'patched-bundle.js'));
let gameWindow = null;
let controlsWindow = null;

function safeKey(key) {
  return ['noclip', 'fly', 'invincible', 'multiJump', 'freeze', 'speed', 'jump'].includes(key);
}

async function execInGame(source) {
  if (!gameWindow || gameWindow.isDestroyed()) return null;
  try {
    return await gameWindow.webContents.executeJavaScript(source, true);
  } catch {
    return null;
  }
}

async function attachBundleInterceptor(win) {
  const dbg = win.webContents.debugger;
  if (!dbg.isAttached()) dbg.attach('1.3');

  dbg.on('message', async (_event, method, params) => {
    if (method !== 'Fetch.requestPaused') return;
    const url = params.request?.url || '';
    const isCubeBundle = /^https:\/\/cubeshift2d\.web\.app\/assets\/index-[^/]+\.js(?:\?.*)?$/.test(url);
    try {
      if (isCubeBundle) {
        await dbg.sendCommand('Fetch.fulfillRequest', {
          requestId: params.requestId,
          responseCode: 200,
          responseHeaders: [
            { name: 'Content-Type', value: 'text/javascript; charset=utf-8' },
            { name: 'Cache-Control', value: 'no-store' }
          ],
          body: PATCHED_BUNDLE.toString('base64')
        });
      } else {
        await dbg.sendCommand('Fetch.continueRequest', { requestId: params.requestId });
      }
    } catch {
      try { await dbg.sendCommand('Fetch.continueRequest', { requestId: params.requestId }); } catch {}
    }
  });

  await dbg.sendCommand('Fetch.enable', {
    patterns: [
      {
        urlPattern: 'https://cubeshift2d.web.app/assets/index-*.js*',
        resourceType: 'Script',
        requestStage: 'Request'
      }
    ]
  });
}

async function createGameWindow() {
  gameWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 650,
    title: 'CubeShift2D Client',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#07101d',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      partition: 'persist:cubeshift2d-client'
    }
  });

  await attachBundleInterceptor(gameWindow);
  await gameWindow.loadURL(GAME_URL);

  gameWindow.on('closed', () => {
    gameWindow = null;
    if (controlsWindow && !controlsWindow.isDestroyed()) controlsWindow.close();
  });
}

function createControlsWindow() {
  controlsWindow = new BrowserWindow({
    width: 390,
    height: 760,
    minWidth: 350,
    minHeight: 620,
    title: 'CubeShift2D Client Controls',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#07101d',
    alwaysOnTop: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  controlsWindow.loadFile(path.join(__dirname, 'controls.html'));
  controlsWindow.on('closed', () => { controlsWindow = null; });
}

ipcMain.handle('hack:set', async (_event, { key, value }) => {
  if (!safeKey(key)) return false;
  const k = JSON.stringify(key);
  const v = JSON.stringify(value);
  return Boolean(await execInGame(`(() => { if (!window.__CUBESHIFT_HACK__) return false; window.__CUBESHIFT_HACK__[${k}] = ${v}; return true; })()`));
});

ipcMain.handle('hack:command', async (_event, { name, args }) => {
  const allowed = ['teleport', 'respawn', 'teleportStart', 'teleportCheckpoint', 'teleportGoal', 'heal', 'collectCoins'];
  if (!allowed.includes(name)) return false;
  const n = JSON.stringify(name);
  const a = JSON.stringify(Array.isArray(args) ? args : []);
  return Boolean(await execInGame(`(() => { const api = window.__CUBESHIFT_DEV_API__; if (!api || typeof api[${n}] !== 'function') return false; api[${n}](...${a}); return true; })()`));
});

ipcMain.handle('hack:state', async () => {
  return await execInGame(`(() => window.__CUBESHIFT_DEV_API__?.getState?.() ?? null)()`);
});

ipcMain.handle('game:reload', async () => {
  if (!gameWindow || gameWindow.isDestroyed()) return false;
  gameWindow.webContents.reloadIgnoringCache();
  return true;
});

ipcMain.handle('game:focus', async () => {
  if (!gameWindow || gameWindow.isDestroyed()) return false;
  gameWindow.show();
  gameWindow.focus();
  return true;
});

ipcMain.handle('game:devtools', async () => {
  if (!gameWindow || gameWindow.isDestroyed()) return false;
  gameWindow.webContents.openDevTools({ mode: 'detach' });
  return true;
});

app.whenReady().then(async () => {
  await createGameWindow();
  createControlsWindow();

  app.on('activate', () => {
    if (!gameWindow) createGameWindow();
    if (!controlsWindow) createControlsWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
